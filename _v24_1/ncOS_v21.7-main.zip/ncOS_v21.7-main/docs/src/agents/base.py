"""
Base module for agents
"""
