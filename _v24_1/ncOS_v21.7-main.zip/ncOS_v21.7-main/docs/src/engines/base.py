"""
Base module for engines
"""
