"""
Vector module for engines
"""
