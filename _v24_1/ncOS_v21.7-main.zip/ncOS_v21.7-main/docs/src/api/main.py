from ncOS import ncos_launcher

if __name__ == "__main__":
    ncos_launcher.main()
