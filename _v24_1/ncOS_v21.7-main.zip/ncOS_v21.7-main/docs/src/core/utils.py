"""
Utils module for core
"""
