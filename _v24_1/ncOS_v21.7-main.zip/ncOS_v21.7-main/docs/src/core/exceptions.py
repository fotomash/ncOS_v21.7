"""
Exceptions module for core
"""
