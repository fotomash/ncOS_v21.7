# Startup Blueprint

```json
{
  "name": "CareMatch MVP 1.0",
  "services": ["nannies", "cleaners"],
  "entry_mode": "freemium + PAYG",
  "launch_region": "Poland and UK"
}

```